FORMAT = "utf-8"
HEARTBEAT_INTERVAL = 300  # seconds

# Key generation for encryption (only needs to be done once)
# from cryptography.fernet import Fernet
# key = Fernet.generate_key()
# print(key.decode())

ENCRYPTION_KEY = b'KP_gBmwmz7Ngb2NQCj8zpKR_sMSCDAPg5fgbnVlpp5o='
